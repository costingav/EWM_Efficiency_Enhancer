sap.ui.define(["bearingpointewm/material_maintenance/test/unit/controller/Materials.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map