sap.ui.require(["bearingpoint/ewm/materialmaintenance/test/integration/AllJourneys"],function(){QUnit.config.autostart=false;QUnit.start()});
//# sourceMappingURL=opaTests.qunit.js.map